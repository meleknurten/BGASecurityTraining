#!/usr/bin/python
from scapy.all import *

#Step 2: Read the PCAP usimg rdpcap
packets = rdpcap("example.pcap")

#Step 3: Loop and print an IP in a packet in Scapy by looking at Layer 3
for pkt in packets:
	if IP in pkt:
		try:
			print("SRC:",pkt[IP].src)
			print("DST:" , pkt[IP].dst)
			print("DATA:",pkt[IP].data)
		except:
			pass

