#!/usr/bin/env bash

if [ ! $# -eq 1 ]
then
	echo "Usage: $0 <ip/cidr>"
	exit 1
fi

subnet=$1

echo "$subnet" | grep -Eq "^([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]+$"
if [ ! $? -eq 0 ]
then
	echo "Usage: $0 <IP>"
	exit 2
fi

function ping2 () {

	scan_subnet=$1
	value=$2

	echo "$scan_subnet- $value"

	nmap -n -sL "$scan_subnet" | grep -E "^Nmap scan report" | cut -d " " -f5 | while read ip
	do
		ping "$ip" -c 1 -w 1 |grep -Eq "^64 bytes from"
		if [ $? -eq 0 ]
		then
			echo "$ip : UP"
		else
			echo "$ip : DOWN"
		fi
	done

}

ping2 "$subnet" "DENEME"











