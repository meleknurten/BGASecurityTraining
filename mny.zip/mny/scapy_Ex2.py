#!/usr/bin/python
from scapy.all import *

def read_file(self, filename):
        if not scapy_installed:
            exit("Could not read pcap due to missing scapy")
        self.params['ppid']=0
        print "Opening pcap file %s" % filename
        packets=rdpcap(filename)
        for p in packets:
            if scapy_sctp and SCTPChunkData in p:
                msg=p.data
            elif (TCP in p and Raw in p) or UDP in p or (Ethernet in p and Raw in p):
                msg = p.load
            if p.time >= self.start and p.time <= self.stop:
                self.packets.append(msg)
                self.uniquesamples.add(msg)
            ppid=getattr(p,'proto_id',0)
            if self.params['ppid'] != ppid:
                self.params['ppid'] = ppid
