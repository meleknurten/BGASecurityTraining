#!/usr/bin/env python

from sys import exit as E
import sys

if __name=="__main__":
	print "Hello World"
	sys.exit(1)

