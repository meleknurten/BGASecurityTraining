#!/usr/env python
import sys


def read_file(filename):
	print " ".join([line.strip(":")[0] for line in open(filename, "r") if not line[0] == "r" ])

if __name__== "__main__":

	if not len(sys.argv)==2:
		print >> sys.stderr, "Usage: {0} FILE".format(sys.argv[0])
		sys.exit(1)



islem_tablosu = ("toplama","carpma","bolme", "cikarma")
rakam1=sys.argv[1]
rakam2=sys.argv[2]
islem=sys.argv[3]
print type(rakam1)
