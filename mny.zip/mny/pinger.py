
import os
import sys
import yaml
import shlex
import argparse
import subprocess


class CMD(object):

    def __init__(self):
        usage = "Usage: use --help for further information"
        description = "Nmap Scanner"
        parser = argparse.ArgumentParser(description = description, usage = usage)

        parser.add_argument('-c', '--config', dest = 'config', action = 'store', help = 'Configuration File', required = True)
        self.__args = parser.parse_args()

        self.__nmap_cmd_path = "/usr/bin/nmap"
        self.__hydra_cmd_path = "/usr/bin/hydra"
        self.__arpscan_cmd_path = "/usr/sbin/arp-scan"


    def __run_cmd(self):
    
        print "KOMUTUM BEN CALISCAM"


    def __parse_yaml(self, config_file):
    
        try:    
            with open(config_file, 'r') as stream:
                config_values = yaml.safe_load(stream)    
                return config_values
        except Exception, err:
            print >> sys.stderr, "Error: '{0}'".format(err)
            sys.exit(1)


    def _run(self):

        config_file =  self.__args.config
        values = self.__parse_yaml(config_file)
        
        username_file = values['General']['Username']
        password_file = values['General']['Password']

        for is_file_exists in  (username_file, password_file, self.__arpscan_cmd_path, self.__nmap_cmd_path, self.__hydra_cmd_path):
            if not os.path.exists(is_file_exists):
                print >> sys.stderr, "File: '{0}' Doesn't Exists !!!".format(is_file_exists)
                sys.exit(2)

        
        

##
### Main
##      

if __name__ == "__main__":

    cmd = CMD()
    cmd._run()

    sys.exit(0)

    """
    arp_cmd = shlex.split("arp-scan -l -I {0}".format(interface)

    proc = subprocess.Popen(cmd_list, shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE,)
    out, err = proc.communicate()

    print out
    """
