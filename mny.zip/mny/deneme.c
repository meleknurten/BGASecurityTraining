#include <stdio.h>


int func(int sayi[]);
int main(void) {

int sayi[12];
	printf("Hello World\n");
	func(sayi);
	exit(0);

}
int func(int sayi[12]){
	for(int i=0;i<12;++i){
		sayi[i]=i;
		printf("Integer: %d \n",sayi[i]);
	}

return 0;
}
