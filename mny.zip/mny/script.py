#!/usr/bin/env python

import sys

def read_file(filename):
    print " ".join([ line.split(":")[0] for line in open(filename, "r") if not line[0] == "r" ])




if __name__ == "__main__":
    
    if not len(sys.argv) == 2:
        print >> sys.stderr, "Usage: {0} FILE".format(sys.argv[0])
        sys.exit(1)

    passwd_file = sys.argv[1]
    
    read_file(passwd_file)

